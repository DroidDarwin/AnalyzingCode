Tools needed by the process.

To make them on a 32-bit machine, type:
	make -f Makefile-32 clean
	make -f Makefile-32 

To make them on a 64-bit machine, type:
	make -f Makefile-64 clean
	make -f Makefile-64 
