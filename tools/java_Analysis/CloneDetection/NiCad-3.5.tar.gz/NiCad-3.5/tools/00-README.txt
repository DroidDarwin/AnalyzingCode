Tools needed by the process.

To make them all, type:

	make

To recompile them all, type:

	make clean
	make

To recompile them from Turing+ source
if you are changing it (requires Turing+ 2009 
(tpc) to be installed), type:

	make reset
	make


